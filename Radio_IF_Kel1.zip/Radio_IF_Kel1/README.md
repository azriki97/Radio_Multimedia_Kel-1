# radio_streamer

My first solo go at a JavaScript Application.

I know it is quite cringe but I will be uploading updates as I learn more. Right now I am trying to figure out how to catch the stream link errors (As at now I have managed to fix). Any suggestion will be highly appreciated.

Check it out [here](https://ryankoech.github.io/radio_streamer/)!

Thank You :)
